package com.company;

public enum Language {
    English,
    Russian,
    Hindi,
    Marathi,
    Gujarati,
    Tatar
}
