package com.company;

interface GoogleTranslator<T> {
    T getAudioFromText(byte[] file, String language);
    /**
     * .
     * .
     * .
     */
}
