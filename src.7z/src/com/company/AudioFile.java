package com.company;

import java.io.File;

//client interface
interface AudioFile {
    AudioFile getAudioFile();
}
